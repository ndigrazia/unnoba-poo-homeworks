package com.example.demo.entity;

public enum Rol {
    ADMINISTRADOR, EVALUADOR, CONCURSANTE
}
