package ar.edu.unnoba.poo2023;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Poo2023ApplicationTests {

	@Test
	void contextLoads() {
	}

}
