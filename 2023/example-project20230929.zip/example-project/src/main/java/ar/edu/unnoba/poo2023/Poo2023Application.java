package ar.edu.unnoba.poo2023;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Poo2023Application {

	public static void main(String[] args) {
		SpringApplication.run(Poo2023Application.class, args);
	}

}
