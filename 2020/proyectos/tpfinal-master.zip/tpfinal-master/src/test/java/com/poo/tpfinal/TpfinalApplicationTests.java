package com.poo.tpfinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpfinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
