package com.hotelsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelsystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
