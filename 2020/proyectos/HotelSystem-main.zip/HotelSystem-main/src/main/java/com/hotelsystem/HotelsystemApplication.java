package com.hotelsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelsystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(HotelsystemApplication.class, args);
    }

}
